Este programa esta conformado por 3 archivos, el .c en el cual se encuentra el código, el .exe que nos sirve para correr el código y el movies.csv en el cual se encuentran los datos que se usan en el código. 

Para compilar el programa se ejecuta por medio de la línea de comandos. (verificamos encontrarnos en la dirección donde se encuentra la carpeta del proyecto) Luego, ingresamos los siguientes comandos en la terminal.

1.-Para ejecutar el archivo .c y generar el .exe colocamos el siguiente comando 
gcc program.c -o ada3

2.- Para ejecutar el archivo .exe y obtener el archivo de salida .txt 
./ada3.exe 

3- En las opciones que arrojan primero le damos a la opción 1 para que importe los datos y de ahí se hacen las modificaciones que el usuario requiera